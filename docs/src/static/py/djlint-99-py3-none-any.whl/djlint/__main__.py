"""Djlint access through python -m djlint."""
from djlint import main

main()
